redux-extension-boilerplate
===========================

Example boilerplate for Redux extensions.
